package bataillenavale.jeu;

import bataillenavale.interfaceutilisateur.Controleur;

public class BatailleNavaleMain
{	
	//-------------Main--------------------

	public static void main(String[] args)
	{	
		Joueur joueur = new Joueur();
		@SuppressWarnings("unused")
		Controleur controleur = new Controleur(joueur);
	}
}
