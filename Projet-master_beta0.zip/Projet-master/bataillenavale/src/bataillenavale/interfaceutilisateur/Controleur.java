package bataillenavale.interfaceutilisateur;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import bataillenavale.jeu.Case;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Controleur extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private bataillenavale.interfaceutilisateur.Fenetre jeu;
	private bataillenavale.jeu.Joueur player;

	  private int etatJeu = 0; // cette variable vaut 0 si le jeu n'a pas encore commence, 1 si le jeu a dej� commence
	  private int aqui = 0; // � qui de jouer (1 si joueur actuel, 2 si joueur adversaire)
	  private int bateau_select = 0; // vaut 0 si aucun bateau n'est selectionne, 1 s'il y a un bateau selectionne
	  // sauvegarde de la selection d'une case
	  private int x_select = 0;
	  private int y_select = 0;
	  // entier pour savoir si une case est selectionne ou pas (necessaire pour permettre de valider cette option)
	  private int case_select = 0;

	  // entier pour gerer les cliques sur les bateaux
	   private int[] etatBateaux = new int[5]; // pour verifier s'ils ont ete attribues, ou non
	    // vaut 0 si pas attribues
	    // 1 si en cours d'�tre selectionnes
	    // 2 si dej� selectionne


		public Controleur(bataillenavale.jeu.Joueur player) {
			this.player = player;
			this.setLayout(new BorderLayout(1,1));
			jeu = new Fenetre(this);
			jeu.setVisible(true);

			// on initialise les valeurs pour les etats des bateaux (valent tous 0 car pas encore attribues)
			for(int i=0; i<5; i++){
				etatBateaux[i] = 0;
			}
		}

		public void quijoue(){
			if(aqui == 1){
				System.out.println("C'est au tour de joueur 1");
			}
			else if(aqui == 2){
				System.out.println("C'est au tour de joueur 2");
			}
			else if(aqui == 0){
				System.out.println("De Dieu! Le jeu n'a m�me pas encore commence");
			}
			else {
				System.out.println("ERREUR: variable aqui");
			}
		}

		// cette methode met la couleur que la case doit avoir si elle n'est pas selectionne

		public void bonCouleurJoueur(JButton bouton, int x, int y){
			// TODO: avec les booleans de la var case
			// TODO: fonction inutile pour l'instant, met elle a son utilite pour enlever les setbackground plus bas

			if(player.getGrilleJoueur().getCase(x -1, y - 1).isBateau() && player.getGrilleJoueur().getCase(x -1, y - 1).isTir()){
				bouton.setBackground(Color.black);

			}
			else if(player.getGrilleJoueur().getCase(x -1, y - 1).isBateau()){
				bouton.setBackground(Color.GRAY);
			}
			else if(player.getGrilleJoueur().getCase(x -1, y - 1).isTir()){
				bouton.setBackground(Color.orange);
			}
			else{
				bouton.setBackground(null);
			}

			//System.out.println("Actualise");

		}

		public void bonCouleurAdv(JButton bouton, int x, int y){
			if(player.getGrilleEnnemi().getCase(x -1, y - 1).isBateau() && player.getGrilleEnnemi().getCase(x -1, y - 1).isTir()){
				bouton.setBackground(Color.black);
			}
			else if(player.getGrilleEnnemi().getCase(x -1, y - 1).isBateau()){
				bouton.setBackground(Color.GRAY);
			}
			else if(player.getGrilleEnnemi().getCase(x -1, y - 1).isTir()){
				bouton.setBackground(Color.orange);
			}
			else{
				bouton.setBackground(null);
			}

			//System.out.println("Actualise");

		}

	    public void deselect(){
	        x_select = 0;
	        y_select = 0;
	      }
	    
	    public void endGame(){
	    	if(player.whoWin() == 1){
	    		JOptionPane.showMessageDialog(null,"Bien joue, vous avez gagne!");
	    		jeu.remove(jeu.getDroite());
	    		jeu.remove(jeu.getGauche());
	    		jeu.invalidate();
	    		jeu.validate();
	    	}
	    	else if(player.whoWin() == 2){
	    		JOptionPane.showMessageDialog(null,
	    			    "RIP, vous avez perdu!");
	    		jeu.remove(jeu.getDroite());
	    		jeu.remove(jeu.getGauche());
	    		//TODO: faire un message pour recommencer
	    		jeu.invalidate();
	    		jeu.validate();
	    	}
	    	else if(player.whoWin() == 0){
	    		System.out.println("next tour");
	    	}
	    }
	    
	public void setRadioButtonsforShips(){
		// cette methode est appele pour mettre en norme les radioButtons (rendre impossible le fait de couler plus d'un porte-avion, 
		// deux torpilleurs, deux croiseurs

		if(player.getCVEnnemi() >= 1){ // porte avion
			jeu.getRadioButtons()[2].setEnabled(false);
			jeu.getRadioButtons()[2].setSelected(false);
		}
		if(player.getCAEnnemi() >= 2){ // croiseurs
			jeu.getRadioButtons()[3].setEnabled(false);
			jeu.getRadioButtons()[3].setSelected(false);
			
		}
		if(player.getDDEnnemi() >= 2){ // torpilleur
			jeu.getRadioButtons()[4].setEnabled(false);
			jeu.getRadioButtons()[4].setSelected(false);
		}
		
		jeu.getGauche().invalidate();
		jeu.getGauche().validate();
		
	}

    public void actionPerformed(ActionEvent e){
			  Object source = e.getSource();

        if(etatJeu == 0){ ////////* Code qui g�re avant le commencement du jeu *//////////
          // jeu n'a pas encore commence
        							
            int nbbateauxplaces = 0;
            for(int k=0; k<5;k++){
                if(etatBateaux[k] == 2){
                   nbbateauxplaces++;
                 }
               }

            for(int i=0; i<5;i++){
             // si on clique sur un bateaux
              if(source == jeu.getBateaux()[i]){

                if(etatBateaux[i] == 0){
                    // on verifie qu'aucun autre bateau n'est selectionne
                    int autrebateauxselectionne = 0;
                    for(int j=0; j<5;j++){
                     if(i !=j && etatBateaux[j] == 1){
                        autrebateauxselectionne = 1;
                      }
                    }

                   if(autrebateauxselectionne == 0){
                      // si aucun d'autre bateau n'est selectionne, on le selectionne
                      etatBateaux[i] = 1;// on le selectionne
                      jeu.getBateaux()[i].setBackground(Color.WHITE);
                      jeu.getGauche().invalidate();
                      jeu.getGauche().validate();
                      System.out.println("bateau" + i +" selectionne");
                      // on vient de selectionner le bateau
                      bateau_select = 1;

                   }
                   else if(autrebateauxselectionne == 1){
                     // si un autre bateau est selectionne
                     System.out.println("Un autre bateau est dej� selectionne.");
                   }
                   else {
                     // probl�me
                   }
                }
                else if(etatBateaux[i] == 1){
                    // si on clique sur un bateau qui etait selectionne, on le deselectionne
                    jeu.getBateaux()[i].setBackground(null);
                    etatBateaux[i] = 0;
                    bateau_select = 0;
                    if(x_select != 0 && y_select != 0 ){
                    jeu.getBoutonJoueur()[x_select][y_select].setBackground(null);
                    deselect();
                    }

                }
                else if(etatBateaux[i] == 2){
                    // le bateau est dej� place, on va le retirer
                  // on deslectionne la case que le joueur � clique
                    if(x_select != 0 && y_select != 0 ){
                    jeu.getBoutonJoueur()[x_select][y_select].setBackground(null);
                    deselect();
                    }
                  etatBateaux[i] = 0;
                  jeu.getBateaux()[i].setBackground(null);
                  if(i == 0){ // on va supprimer le porte-avion
                      for(Case caseBateau: player.getCV1().getPosition()){
                        int abs = caseBateau.getCoordX();
                        int ord = caseBateau.getCoordY();
                        jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(null);
                        jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(true);
                      }
                      player.destroyCV1();
                      System.out.println("Le porte-avion a bien ete supprime");
                  }
                  else if(i == 1){ // on va supprimer le croiseur 1
                      for(Case caseBateau: player.getCA1().getPosition()){

                        int abs = caseBateau.getCoordX();
                        int ord = caseBateau.getCoordY();

                        jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(null);
                        jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(true);
                      }
                      player.destroyCA1();
                      System.out.println("Le croiseur 1 a bien ete supprime");
                  }
                  else if(i == 2){
                      for(Case caseBateau: player.getCA2().getPosition()){

                        int abs = caseBateau.getCoordX();
                        int ord = caseBateau.getCoordY();

                        jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(null);
                        jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(true);
                      }
                      player.destroyCA2();
                      System.out.println("Le croiseur 2 a bien ete supprime");
                  }
                  else if(i == 3){ // torpilleur 1
                      for(Case caseBateau: player.getDD1().getPosition()){
                        int abs = caseBateau.getCoordX();
                        int ord = caseBateau.getCoordY();
                        jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(null);
                        jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(true);
                      }
                      player.destroyDD1();
                      System.out.println("Le torpilleur 1 a bien ete supprime");
                  }
                  else if(i == 4){
                      for(Case caseBateau: player.getDD2().getPosition()){
                        int abs = caseBateau.getCoordX();
                        int ord = caseBateau.getCoordY();
                        jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(null);
                        jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(true);
                      }
                      player.destroyDD2();
                      System.out.println("Le  torpilleur 2 a bien ete supprime");
                      }

                              }
                  else{
                      // aucun cas
                      System.out.println("ERREUR: variable etatBateaux");
                  }
                }

              }

              for(int i=1; i<11;i++){
                for(int j=1; j<11;j++){
                  if(source == jeu.getBoutonJoueur()[i][j]){
                    //un bouton a ete clique, jeu pas commence
                    // si aucun bateau n'a ete selectionne

                	
                    if(bateau_select == 0 && nbbateauxplaces < 5){
                        System.out.println("Merci de selectionnez un bateau");
                    }
                    else if(bateau_select == 0 && nbbateauxplaces == 5){
                    	System.out.println("Tout les bateaux sont dej� places");
                    }
                    // si un bateau a ete selectionne et que l'on vient de selectionne la premi�re case
                    else if(x_select == 0 && y_select == 0 && bateau_select == 1){
                      // on selectionne le point
                      x_select = i;
                      y_select = j;
                      jeu.getBoutonJoueur()[i][j].setBackground(Color.GRAY); // on met la couleur grise pour un bateau
                                           
                    }
                    // si on reclique sur le bouton qui a ete selectionne, on le deselectionne
                    else if(x_select == i && y_select == j && bateau_select == 1){
                      jeu.getBoutonJoueur()[i][j].setBackground(null);
                      deselect();
                    }
                    // on selectionne le deuxi�me point (premier point sauvegarde et on clique sur un autre point
                    else if(x_select != 0 && y_select != 0 && bateau_select == 1){
                      // on a un bateau + deux cases
                      // on fait le check setBateau -> true, on remet bateau_select � 0, le bateau selectionne a 2
                      // x et y select � 0

                          if(etatBateaux[0] == 1){ // on veut tenter de placer un porte-avion

                            if(player.setCV1(x_select - 1, y_select - 1, i - 1, j - 1)){
                              // on a reussi � placer le bateau
                              for(Case caseBateau: player.getCV1().getPosition()){

                                int abs = caseBateau.getCoordX();
                                int ord = caseBateau.getCoordY();

                                jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(Color.gray);
                                jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(false);
                              }
                              etatBateaux[0] = 2;
                              bateau_select = 0;
                              jeu.getBateaux()[0].setBackground(Color.GREEN.darker());
                              deselect();
                              System.out.println("Porte avion place");
                            }
                            else{
                              // on lui enl�ve la selection sur cette case
                              jeu.getBoutonJoueur()[i][j].setBackground(null);
                              // on ne deselect pas la prem�re case
                            }


                          }
                          else if(etatBateaux[1] == 1){ // on veut tenter de placer le croiseur 1

                            if(player.setCA1(x_select - 1, y_select - 1, i - 1, j - 1)){
                              // on a reussi � placer le bateau
                              for(Case caseBateau: player.getCA1().getPosition()){

                                int abs = caseBateau.getCoordX();
                                int ord = caseBateau.getCoordY();

                                jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(Color.gray);
                                jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(false);
                              }
                              etatBateaux[1] = 2;
                              bateau_select = 0;
                              jeu.getBateaux()[1].setBackground(Color.GREEN.darker());
                              deselect();
                              System.out.println("Croiseur 1 place");
                            }
                            else{
                              // on lui enl�ve la selection sur cette case
                              jeu.getBoutonJoueur()[i][j].setBackground(null);
                            }
                          }
                          else if(etatBateaux[2] == 1){ // on veut tenter de placer le croiseur 2

                            if(player.setCA2(x_select - 1, y_select - 1, i - 1, j - 1)){
                              // on a reussi � placer le bateau
                              for(Case caseBateau: player.getCA2().getPosition()){

                                int abs = caseBateau.getCoordX();
                                int ord = caseBateau.getCoordY();

                                jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(Color.gray);
                                jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(false);
                              }
                              etatBateaux[2] = 2;
                              deselect();
                              jeu.getBateaux()[2].setBackground(Color.GREEN.darker());
                              System.out.println("Croiseur 2 place");
                              bateau_select = 0;
                            }
                            else{
                              // on lui enl�ve la selection sur cette case
                              jeu.getBoutonJoueur()[i][j].setBackground(null);
                            }
                          }
                          else if(etatBateaux[3] == 1){ // on veut tenter de placer le torpilleur 1

                            if(player.setDD1(x_select - 1, y_select - 1, i - 1, j - 1)){
                              // on a reussi � placer le bateau
                              for(Case caseBateau: player.getDD1().getPosition()){

                                int abs = caseBateau.getCoordX();
                                int ord = caseBateau.getCoordY();

                                jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(Color.gray);
                                jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(false);
                              }
                              etatBateaux[3] = 2;
                              deselect();
                              jeu.getBateaux()[3].setBackground(Color.GREEN.darker());
                              System.out.println("Torpilleur 1 place");
                              bateau_select = 0;
                            }
                            else{
                              // on lui enl�ve la selection sur cette case
                              jeu.getBoutonJoueur()[i][j].setBackground(null);
                            }
                          }
                          else if(etatBateaux[4] == 1){ // on veut tenter de placer le torpilleur 2

                            if(player.setDD2(x_select - 1, y_select - 1, i - 1, j - 1)){
                              // on a reussi � placer le bateau
                              for(Case caseBateau: player.getDD2().getPosition()){

                                int abs = caseBateau.getCoordX();
                                int ord = caseBateau.getCoordY();

                                jeu.getBoutonJoueur()[abs+1][ord+1].setBackground(Color.gray);
                                jeu.getBoutonJoueur()[abs+1][ord+1].setEnabled(false);
                              }
                              etatBateaux[4] = 2;
                              deselect();
                              jeu.getBateaux()[4].setBackground(Color.GREEN.darker());
                              System.out.println("Torpilleur 2 place");
                              bateau_select = 0;
                            }
                            else{
                              // on lui enl�ve la selection sur cette case
                              jeu.getBoutonJoueur()[i][j].setBackground(null);
                            }
                          }

                        }

                      }
                    }
                  }
              
              if(source == jeu.getStartButton() && nbbateauxplaces == 5){
            	  // bouton start
					System.out.println("Tout les bateaux ont ete places... � qui de commencer?");
					  // TODO: demander si joueur 1 commence ou joueur 2
					aqui = 1;
					System.out.println("Je vous laisse commencer.");
					

					// on change le panel de gauche pour commencer � jouer
				    jeu.getGauche().remove(jeu.getBeforeStart());
				    jeu.getGauche().add(jeu.getAfterStart(), BorderLayout.SOUTH);
				    jeu.getValiderButton().setEnabled(false);
				    jeu.getGauche().invalidate();
				    jeu.getGauche().validate();
				    // On active les boutons sur les deux tables
					  for(int i=1; i<11;i++){
						  for(int j=1; j<11;j++){
							  jeu.getBoutonAdv()[i][j].setEnabled(true);
							  jeu.getBoutonJoueur()[i][j].setEnabled(true);
						  }
						 }
					 // on indique que le jeu a commence
					 etatJeu = 1;
              }
              else if(source == jeu.getStartButton() && nbbateauxplaces < 5){
					System.out.println("Vous avez oubliez de placer certains bateaux, merci de les placer.");
					JOptionPane.showMessageDialog(null, "Vous avez oubliez de placer des bateaux", "Erreur: Impossible de lancer le jeu", JOptionPane.ERROR_MESSAGE);

              }
            }

            else if(etatJeu == 1){ ///////////* code qui g�re apr�s le commencement du jeu *////////////////
              // jeu � commence
            	// on va gerer les radiosboutons

            	if(source == jeu.getRadioButtons()[1]){

					   if(jeu.getRadioButtons()[1].isSelected()){
					     jeu.getRadioButtons()[0].setSelected(false);    
					     jeu.getRadioButtons()[2].setEnabled(true);
					     jeu.getRadioButtons()[3].setEnabled(true);
					     jeu.getRadioButtons()[4].setEnabled(true);
					     }
					   else {
					       jeu.getRadioButtons()[0].setSelected(true);
					       jeu.getRadioButtons()[2].setSelected(false);
					       jeu.getRadioButtons()[3].setSelected(false);
					       jeu.getRadioButtons()[4].setSelected(false);
					       jeu.getRadioButtons()[2].setEnabled(false);
					       jeu.getRadioButtons()[3].setEnabled(false);
					       jeu.getRadioButtons()[4].setEnabled(false);
					     }

            	}
            	else if(source == jeu.getRadioButtons()[0]){
					     if(jeu.getRadioButtons()[0].isSelected()){
					       jeu.getRadioButtons()[1].setSelected(false);
					       jeu.getRadioButtons()[2].setSelected(false);
					       jeu.getRadioButtons()[3].setSelected(false);
					       jeu.getRadioButtons()[4].setSelected(false);
					       jeu.getRadioButtons()[2].setEnabled(false);
					       jeu.getRadioButtons()[3].setEnabled(false);
					       jeu.getRadioButtons()[4].setEnabled(false);

					     }
					     else{
					       jeu.getRadioButtons()[1].setSelected(true);
					       jeu.getRadioButtons()[2].setEnabled(true);
					       jeu.getRadioButtons()[3].setEnabled(true);
					       jeu.getRadioButtons()[4].setEnabled(true);
					     }
            	}
            	else if(source == jeu.getRadioButtons()[2]){

					     if(jeu.getRadioButtons()[2].isSelected()){
					       jeu.getRadioButtons()[3].setSelected(false);
					       jeu.getRadioButtons()[4].setSelected(false);
					       jeu.getRadioButtons()[1].setSelected(true);
					       //
					       jeu.getRadioButtons()[0].setSelected(false);
					     }
            	}
            	else if(source == jeu.getRadioButtons()[3]){
					     if(jeu.getRadioButtons()[3].isSelected()){
					       jeu.getRadioButtons()[2].setSelected(false);
					       jeu.getRadioButtons()[4].setSelected(false);
					       jeu.getRadioButtons()[1].setSelected(true);
					       //
					       jeu.getRadioButtons()[0].setSelected(false);
					     }
            	}
            	else if(source == jeu.getRadioButtons()[4]){
				       if(jeu.getRadioButtons()[4].isSelected()){
				         jeu.getRadioButtons()[2].setSelected(false);
				         jeu.getRadioButtons()[3].setSelected(false);
				         jeu.getRadioButtons()[1].setSelected(true);
				         //
				         jeu.getRadioButtons()[0].setSelected(false);

				       }
            	}
            	setRadioButtonsforShips();
            
            	
            	// fin de la gerance des RadioButtons
            	if(aqui == 1){ // joueur 1 qui joue, reagit uniquement pour les caseadv
            		  if(case_select == 0){ // aucune case selectionne
            		  	  for(int i=1; i<11;i++){
            		  		  for(int j=1; j<11;j++){
            		  			     if(source == jeu.getBoutonAdv()[i][j]){
            		               // le joueur selectionne la case
            		               case_select = 1;
            		               x_select = i;
            		               y_select = j;
            		               jeu.getBoutonAdv()[i][j].setBackground(Color.green);
            		               jeu.getValiderButton().setEnabled(true);
            		             }
            		  		  }
            		  		 }
            		  }
            		  else if(case_select == 1){
            		   
            		    for(int i=1; i<11;i++){
            		      for(int j=1; j<11;j++){
            		           if(source == jeu.getBoutonAdv()[i][j] && x_select == i && y_select == j){
            		        	   // si on clique sur la meme case, on la desactive
            		             case_select = 0;
            		             deselect();
            		             bonCouleurAdv(jeu.getBoutonAdv()[i][j], i, j);
            		             jeu.getValiderButton().setEnabled(false);
            		           }
            		           else if(source == jeu.getBoutonAdv()[i][j]){
            		        	   // si on clique sur une autre, on desactive celle l�, et on active lautre
            		        	   bonCouleurAdv(jeu.getBoutonAdv()[x_select][y_select], x_select, y_select);
            		        	   x_select = i;
            		        	   y_select = j;
            		        	   jeu.getBoutonAdv()[i][j].setBackground(Color.green);
            		        	   jeu.getValiderButton().setEnabled(true);
             		              
            		           }
            		      }
            		    }
            		    
            		    // si on clique sur valider
            		    if(source == jeu.getValiderButton()){
            		    	if(case_select == 1){
            		    	  if(jeu.getRadioButtons()[0].isSelected()){
            		    	    // on a tire dans l'eau
            		    	    aqui = 2;
            		    	    // on desactive les radioButtons
     					       	jeu.getRadioButtons()[0].setEnabled(false);
     					       	jeu.getRadioButtons()[1].setEnabled(false);
            		    	    jeu.getBoutonAdv()[x_select][y_select].setEnabled(false);
            		    	    jeu.getBoutonAdv()[x_select][y_select].setBackground(Color.blue);
            		    	    player.setCoupDansEau(x_select - 1, y_select - 1);
            		    	 
            		    	  }
            		    	  else if(jeu.getRadioButtons()[1].isSelected() && jeu.getRadioButtons()[2].isSelected()) {
            		    	    //on a touche + porte avion coule
            		    	    jeu.getBoutonAdv()[x_select][y_select].setEnabled(false);
            		    	    jeu.getBoutonAdv()[x_select][y_select].setBackground(Color.black);
            		    	    if(player.setCVCoule(x_select - 1, y_select - 1)){
            		    	    	endGame();
            		    	    }
            		    	   
            		    	  }
            		    	  else if(jeu.getRadioButtons()[1].isSelected() && jeu.getRadioButtons()[3].isSelected()) {
            		    	    //touche + torpilleur coule
            		    	    if(player.setCACoule(x_select - 1, y_select - 1)){
            		    	    	endGame();
            		    	    }
            		    	     jeu.getBoutonAdv()[x_select][y_select].setEnabled(false);
            		    	     jeu.getBoutonAdv()[x_select][y_select].setBackground(Color.black);
            		    	     
            		    	  }
            		    	  else if(jeu.getRadioButtons()[1].isSelected() && jeu.getRadioButtons()[4].isSelected()) {
            		    	    //touche + croiseur coule
            		    	    if(player.setDDCoule(x_select - 1, y_select - 1)){
            		    	    	endGame();
            		    	    }
            		    	     jeu.getBoutonAdv()[x_select][y_select].setEnabled(false);
            		    	     jeu.getBoutonAdv()[x_select][y_select].setBackground(Color.black);


            		    	  }
            		    	  else if(jeu.getRadioButtons()[1].isSelected()) {
            		    	    //touche
            		    	    jeu.getBoutonAdv()[x_select][y_select].setEnabled(false);
            		    	    jeu.getBoutonAdv()[x_select][y_select].setBackground(Color.black);
            		    	    player.setTouche(x_select - 1, y_select - 1);
            		    	   
            		    	  }
            		    	  else {
            		    	    // cas problematique: aucune sol
            		    	  }
            		    	  // on deselecte
            		    	  deselect();
            		    	  case_select = 0;
            		    	  jeu.getValiderButton().setEnabled(false);
            		    	}
                		    else if(case_select == 0){
                		    	System.out.println("Veuillez selectionner une case svp.");
                		    }
            		    	quijoue();
            		    
            		    }


            		  }
            		  
            		}
            		else if(aqui == 2){

            			if(case_select == 0){
            				
              		  	  for(int i=1; i<11;i++){
            		  		  for(int j=1; j<11;j++){
            		  			     if(source == jeu.getBoutonJoueur()[i][j]){
            		               // le joueur selectionne la case
            		               case_select = 1;
            		               x_select = i;
            		               y_select = j;
            		               jeu.getBoutonJoueur()[i][j].setBackground(Color.green);
            		               jeu.getValiderButton().setEnabled(true);
            		             }
            		  		  }
            		  		 }
            			}
            			else if(case_select == 1){
            				
                		    for(int i=1; i<11;i++){
                  		      for(int j=1; j<11;j++){
                  		           if(source == jeu.getBoutonJoueur()[i][j] && x_select == i && y_select == j){
                  		             // le joueur clique sur la case qu'il a dej� selectionne: on la desactive
                  		             case_select = 0;
                  		             deselect();
                  		             bonCouleurAdv(jeu.getBoutonJoueur()[i][j], i, j);
                  		             jeu.getValiderButton().setEnabled(false);
                  		           }
                  		           else if(source == jeu.getBoutonJoueur()[i][j]){
                  		        	   // si on clique sur une autre, on desactive celle l�, et on active lautre
                  		        	   bonCouleurAdv(jeu.getBoutonJoueur()[x_select][y_select], x_select, y_select);
                  		        	   x_select = i;
                  		        	   y_select = j;
                  		        	   jeu.getBoutonJoueur()[i][j].setBackground(Color.green);
                  		        	   jeu.getValiderButton().setEnabled(true);
                   		              
                  		           }
                  		      }
                  		    }
            			}
            			
            			
            			if(source == jeu.getValiderButton()){
            				if(case_select == 1){
	            			int valeur_joueur = player.setTir(x_select - 1, y_select - 1);
	            			
	            			
	            			
	            			if(valeur_joueur == 0){
	            				// coup dans l'eau
	            				jeu.getBoutonJoueur()[x_select][y_select].setEnabled(false);
	            				jeu.getBoutonJoueur()[x_select][y_select].setBackground(Color.blue);
	            				System.out.println("Indiquez au joueur 1 que: COUP DANS L'EAU");
	            				aqui = 1;
	            				// on reactive les radioButtons
	 					       jeu.getRadioButtons()[0].setEnabled(true);
						       jeu.getRadioButtons()[1].setEnabled(true);
	            				
	            			}
	            			else if(valeur_joueur == 1){
	            				// touche
	            				jeu.getBoutonJoueur()[x_select][y_select].setEnabled(false);
	            				jeu.getBoutonJoueur()[x_select][y_select].setBackground(Color.black);
	            				System.out.println("Indiquez au joueur 1 que: TOUCHE");
	            			}
	            			else if(valeur_joueur == 30){
	            				// torpilleur coule
	            				jeu.getBoutonJoueur()[x_select][y_select].setEnabled(false);
	            				jeu.getBoutonJoueur()[x_select][y_select].setBackground(Color.black);
	            				System.out.println("Indiquez au joueur 1 que: TOUCHE et TORPILLEUR COULE");
	            			}
	            			else if(valeur_joueur == 31){
	            				// torpilleur coule + fin
	            				System.out.println("Indiquez au joueur 1 que: TORPILLEUR COULE ET FIN DU JEU");
	            				jeu.getBoutonJoueur()[x_select][y_select].setEnabled(false);
	            				jeu.getBoutonJoueur()[x_select][y_select].setBackground(Color.black);
	            				endGame();

	            			}
	            			else if(valeur_joueur == 40){
	            				// croiseur coule
	            				System.out.println("Indiquez au joueur 1 que: TOUCHE et CROISEUR COULE");
	            				jeu.getBoutonJoueur()[x_select][y_select].setEnabled(false);
	            				jeu.getBoutonJoueur()[x_select][y_select].setBackground(Color.black);
	            			}	
	            			else if(valeur_joueur == 41){
	            				// croiseur coule + fin
	            				System.out.println("Indiquez au joueur 1 que: TOUCHE et CROISEUR COULE ET FIN DU JEU");
	            				jeu.getBoutonJoueur()[x_select][y_select].setEnabled(false);
	            				jeu.getBoutonJoueur()[x_select][y_select].setBackground(Color.black);
	            				endGame();
	            			}
	            			else if(valeur_joueur == 50){
	            				// porte-avion coule
	            				System.out.println("Indiquez au joueur 1 que: TOUCHE et Porte-avion coule");
	            				jeu.getBoutonJoueur()[x_select][y_select].setEnabled(false);
	            				jeu.getBoutonJoueur()[x_select][y_select].setBackground(Color.black);
	            			}
	            			else if(valeur_joueur == 51){
	            				// porte-avion coule + fin
	            				System.out.println("Indiquez au joueur 1 que: TOUCHE et porte-avion coule et FIN DU JEU");
	            				jeu.getBoutonJoueur()[x_select][y_select].setEnabled(false);
	            				jeu.getBoutonJoueur()[x_select][y_select].setBackground(Color.black);
	            				endGame();
	            				
	            			}
	            			quijoue();
	            			
	            			
	            			// on deselecte
	            			deselect();
	            			case_select = 0;
	            			jeu.getValiderButton().setEnabled(false);
            				}
            				else if(case_select == 0){
            					System.out.println("Veuillez selectionner une case.");
            				}
            			
            			}


            		}

            else{
              // probl�me
            }
      }
    }
}
         

// TODO: enlever les system out println + afficher le texte dans le panel gauchehaut

// TODO: faille du jeu: on peut couler directement les cases du joueur adverse (peut on dire que l'on se base sur la confiance du joueur?)
//?? emp�cher de touche plus de cases que le nombre total de case touche possible??

