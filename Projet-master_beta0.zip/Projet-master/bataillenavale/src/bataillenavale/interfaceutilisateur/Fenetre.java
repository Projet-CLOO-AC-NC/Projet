package bataillenavale.interfaceutilisateur;

import java.awt.*;
//import java.awt.event.*;
//import java.io.PrintStream;
import javax.swing.*;

public class Fenetre extends JFrame{

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// declarations des Panels
    // panel de droite
    private JPanel droite = new JPanel();
      // panel du joueur
      private JPanel casejoueur = new JPanel();

      // panel de l'adversaire
			private JPanel caseadv = new JPanel();
			
			public JPanel choix_joueur = new JPanel();



    // panel de gauche
		private JPanel gauche = new JPanel();
      // panel de display de message
      private JPanel gauchehaut = new JPanel();
      // panel de gauche en bas
        // placement des bateaux
        private JPanel beforeStart = new JPanel();
        // jeu
        private JPanel afterStart = new JPanel();

   // Declarations des boutons pour les Panels
    //pour le joueur et l'adversaire
    private JButton[][] boutonJoueur = new JButton[11][11];
    private JButton[][] boutonAdv = new JButton[11][11];
    // bouton necessaire pour les Panels
    private JButton startButton =  new JButton("Start");
    private JButton validerButton = new JButton("Valider");
    private JButton[] bateaux = new JButton[5]; //il y a 5 bateaux

  // Declarations des radioButtons utilises dans le panel afterStart
    private JRadioButton[] radioButtons = new JRadioButton[5];



    
  public Fenetre(Controleur parent){
  super();

  

  // initialisation des values et on met dans les panels

  // initialisation du Panel general
  this.setTitle("Bataille Navale");
  setLocationRelativeTo(null);
  setResizable(true);
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  setSize(new Dimension(1000,600));

  // initialisation du Panel casejoueur
  casejoueur.setPreferredSize(new Dimension(900,300));
  casejoueur.setLayout(new GridLayout(11,11));

  // initialisation du Panel caseadv
  caseadv.setPreferredSize(new Dimension(900,300));
  caseadv.setLayout(new GridLayout(11,11));

  // initialisation du panel de droite
  droite.setPreferredSize(new Dimension(1000,600));
  droite.setLayout(new GridLayout(2,1));
  droite.add(caseadv);
  droite.add(casejoueur);


  // initialisation du Panel beforeStart
  beforeStart.setPreferredSize(new Dimension(300,600));;
  beforeStart.setLayout(new GridLayout(6,1));

  // initialisation du Panel afterStart
  afterStart.setLayout(new GridLayout(6,1));

  // initialisation du Panel de gauche en haut
  gauchehaut.setPreferredSize(new Dimension(300,150));

  // initialisation du Panel de gauche
  gauche.setPreferredSize(new Dimension(300,300));
  gauche.setLayout(new GridLayout(2,1));
  gauche.add(gauchehaut);
  //gauche.add(afterStart);
  gauche.add(beforeStart);

  // tout mettre en visible, dans le panel principal
  this.setLayout(new GridLayout(1,2));
  this.add(gauche, BorderLayout.EAST);
  this.add(droite, BorderLayout.WEST);
  this.setVisible(true);
  this.setBackground(Color.BLACK);


  // Initialisation des boutons
  // boutons pour joueur et l'adversaire
  for (int i=0 ; i<11 ; i++) {
   for (int j=0 ; j<11 ; j++ ) {
	   boutonJoueur[i][j] = new JButton("");
	   boutonAdv[i][j] = new JButton("");

      if (i == 0 && j == 0) { //première case avec rien
        boutonJoueur[i][j].setText("");
        boutonJoueur[i][j].setEnabled(false);
        boutonJoueur[i][j].setBackground(Color.BLACK);
        boutonAdv[i][j].setText("");
        boutonAdv[i][j].setEnabled(false);
        boutonAdv[i][j].setBackground(Color.BLACK);
      }
      else if(i == 0){
        boutonJoueur[i][j].setText("A");
        boutonJoueur[i][j].setEnabled(false);
        boutonJoueur[i][j].setBackground(Color.BLACK);
        boutonAdv[i][j].setText("A");
        boutonAdv[i][j].setEnabled(false);
        boutonAdv[i][j].setBackground(Color.BLACK);
      }
      else if(j == 0){
    	boutonJoueur[i][j].setText("1");
        boutonJoueur[i][j].setEnabled(false);
        boutonJoueur[i][j].setBackground(Color.BLACK);
        boutonAdv[i][j].setText("1");
        boutonAdv[i][j].setEnabled(false);
        boutonAdv[i][j].setBackground(Color.BLACK);

      } else{
    	  boutonJoueur[i][j].setText("");
          boutonJoueur[i][j].addActionListener(parent);
          boutonAdv[i][j].setText("");
          boutonAdv[i][j].addActionListener(parent);
          // de base, on desactive les boutons des cases adverses
          boutonAdv[i][j].setEnabled(false);;
      }

  		casejoueur.add(boutonJoueur[i][j]);
  		caseadv.add(boutonAdv[i][j]);
    }

  }

  // boutons pour le panel beforeStart
  bateaux[0] = new JButton("Porte-Avion");
  bateaux[1] = new JButton("Croiseur");
  bateaux[2] = new JButton("Croiseur");
  bateaux[3] = new JButton("Torpilleur");
  bateaux[4] = new JButton("Torpilleur");

  for(int i=0; i<5; i++){
	  bateaux[i].addActionListener(parent);
	  beforeStart.add(bateaux[i]);
  }
  startButton.addActionListener(parent);
  startButton.setBackground(Color.GREEN);
  beforeStart.add(startButton);

  //radio boutons pour le afterStart
  radioButtons[0] = new JRadioButton("Coup dans l'eau");
  radioButtons[1] = new JRadioButton("Touche");
  radioButtons[2] = new JRadioButton("Porte-Avion coule");
  radioButtons[3] = new JRadioButton("Torpilleur coule");
  radioButtons[4] = new JRadioButton("Croiseur coule");
  // cas de depart
  radioButtons[0].setSelected(true);
  radioButtons[1].setSelected(false);
  radioButtons[2].setEnabled(false);
  radioButtons[3].setEnabled(false);
  radioButtons[4].setEnabled(false);



  for(int i=0; i<5;i++){
	  radioButtons[i].addActionListener(parent);
	  afterStart.add(radioButtons[i]);
  }
  validerButton.addActionListener(parent);
  validerButton.setBackground(Color.GREEN);
  afterStart.add(validerButton);

  System.out.println("Fin initialisation");

  

  }
  
  
  // methode pour recuperer les attributs

  // les panels
  public JPanel getCaseJoueur(){
    return casejoueur;
  }

  public JPanel getCaseAdv(){
    return caseadv;
  }


  public JPanel getGauche(){
    return gauche;
  }

  public JPanel getDroite(){
    return droite;
  }

  public JPanel getGaucheHaut(){
    return gauchehaut;
  }


  public JPanel getBeforeStart(){
    return beforeStart;
  }


  public JPanel getAfterStart(){
    return afterStart;
  }

  // les boutons
  public JButton getStartButton(){
    return startButton;
  }


  public JButton[][] getBoutonJoueur(){
    return boutonJoueur;
  }

  public JButton[][] getBoutonAdv(){
    return boutonAdv;
  }

  public JButton getValiderButton(){
    return validerButton;
  }

  public JButton[] getBateaux(){
    return bateaux;
  }

  public JRadioButton[] getRadioButtons(){
    return radioButtons;
  }


}

// TODO: faire en sorte que si le joueur doit jouer, de grise les cases adversaires
