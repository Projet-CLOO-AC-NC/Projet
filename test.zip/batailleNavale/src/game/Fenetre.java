package game;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Fenetre extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3687209379921062073L;

	public Fenetre(){
		super();
		build();
	}
	private JButton bouton;
	private JButton bouton2;
	
	private void build(){
		setLayout(null);
		setTitle("Bataille Navale"); //On donne un titre � l'application
		setSize(320,240); //On donne une taille � notre fen�tre
		setLocationRelativeTo(null); //On centre la fen�tre sur l'�cran
		setResizable(true); //On interdit la redimensionnement de la fen�tre
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //On dit � l'application de se fermer lors du clic sur la croix
		setContentPane(buildContentPane());

	}
	
	private JPanel buildContentPane(){

		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());
		// choix couleur du background
		panel.setBackground(Color.red.darker());
		// ajout texte
		JLabel label = new JLabel("Nico et Aslam vous pr�sentent Bataille Navale");
		label.setBounds(new Rectangle(new Point(0,300), label.getPreferredSize()));
		panel.add(label);
		// ajout bouton
		bouton = new JButton("RIP");
		bouton.addActionListener(this);
		bouton.setLocation(300, 220);	
		panel.add(bouton);

		
		bouton2 = new JButton("Call the doctor");
		bouton2.addActionListener(this);
		panel.add(bouton2);
		
		JLabel label2 = new JLabel("PUBLIC CALL BOX");
		
		panel.add(label2).setBackground(Color.cyan.darker());
		

	 
		return panel;
	}	
	
	// ici on doit mettre code pour dire ce que l'on fait quand le bouton est activ�
	// (on �coute le signal)
	public void actionPerformed(ActionEvent e){
		Object source = e.getSource();
		System.out.println("Un bouton a �t� touch�");
		if (source == bouton){
			System.out.println("D�sol�, rien ne peut vous sauvez");
		} 
		else if (source == bouton2){
			System.out.println("Le TARDIS a bien re�u votre appel de d�tresse");
		}


	}


}

